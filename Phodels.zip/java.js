<script type="text/javascript">
    document.getElementById('circle').onclick=function () {
        document.getElementById('circle').style.display="none;"
        
    }
</script>